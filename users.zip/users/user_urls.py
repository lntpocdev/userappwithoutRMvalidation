from django.contrib import admin
from django.urls import path,include
from . import views

urlpatterns = [
    path('admin/',admin.site.urls,name='useradmin'),
    path('token/',views.CustomAuthToken.as_view()),
    path('signup/',views.SignUpFirstPage.as_view(),name='sign_up_email'),
    path('register/',views.SignUpRegistrationPage.as_view(),name='registration'),
    path('login/',views.LoginPage.as_view(),name='login_page'),
    path('forgot_password/',views.ForgotPasswordEmail.as_view(),name='forgot_password'),
    path('reset_password/',views.ResetPassword.as_view(),name='new_password'),
    path('logout/',views.LogoutView.as_view(),name='logout')
]