from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from .serializers import *
import smtplib
from email.message import EmailMessage
import random
from .models import *
import ssl
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from django.contrib.auth.hashers import make_password,check_password
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import TokenAuthentication



# Create your views here.

class CustomAuthToken(ObtainAuthToken):
    def post(self, request, *args, **kwargs):
        serializer = CustomAuthTokenSerializer(data = request.data)
        if serializer.is_valid(raise_exception=True):
            user = serializer.validated_data['email']
            password = serializer.validated_data['password']
            if User.objects.filter(email = user).exists():
                saved_password = User.objects.filter(email=user).values()[0].get('password')  
                if check_password(password,saved_password):
                    user_object = User.objects.get(email=user)
                    token , created = Token.objects.get_or_create(user = user_object)
                    return Response({'token': token.key,'email_id': user})
                    

class SignUpFirstPage(APIView):
    serializer_class = SignUpFirstPageSerializer
    
    
    def post(self, request):
        serializer = SignUpFirstPageSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            recipient_mail  = serializer.validated_data['email']
            if User.objects.filter(email=recipient_mail).exists():
                return Response({'message':'User Already Exists!.. Please login to continue..'},status.HTTP_400_BAD_REQUEST)
            else:
                msg = EmailMessage()
                msg['Subject'] = 'LNT MF Sales Incentive: OTP Registration'
                msg['From'] = 'sharetokiruthik@gmail.com'
                msg['To'] = recipient_mail
                otp = random.randint(100001,999999)
                otp_object = OTP_Verification(email = recipient_mail,OTP = otp)
                otp_object.save()
                content = f'Welcome {recipient_mail}, Your OTP for Registration is {otp}. Please do not the OTP to anyone.'
                msg.set_content(content)
                s = smtplib.SMTP('smtp.gmail.com',port=587)
                context=ssl.create_default_context()
                s.starttls(context=context)
                s.ehlo()
                s.login('sharetokiruthik@gmail.com','FutureFinder')
                s.send_message(msg)
                s.quit()
                return Response({'message':'OTP for Registration is sent to your mail'},status.HTTP_200_OK)    
                
        
class SignUpRegistrationPage(APIView):
    serializer_class= SignUpRegistrationSerializer
    
    def post(self,request):
        serializer = SignUpRegistrationSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            recipient_mail  = serializer.validated_data['email']
            password1  = serializer.validated_data['password1']
            password2  = serializer.validated_data['password2']
            user_otp  = serializer.validated_data['OTP']
            if Admin_Setup.objects.filter(EMAIL = recipient_mail).exists():
                if password1 == password2:
                    hashed = make_password(password1)
                    if OTP_Verification.objects.filter(email = recipient_mail,OTP=user_otp):
                        user_object = User(email = recipient_mail,password=hashed)
                        user_object.save()
                        admin_object = Admin_Setup.objects.filter(EMAIL = recipient_mail).values()[0]
                        user_config_object = Admin_User_Configuration(
                            NAME=admin_object.get('ADMIN_NAME'),
                            EMAIL = admin_object.get('EMAIL'),
                            MOBILE = admin_object.get('MOBILE_NO'),
                            DESIGNATION = admin_object.get('DESIGNATION'),
                            PASSWORD = hashed  
                        )
                        user_config_object.save()
                        if User.objects.filter(email=recipient_mail):
                            token , created = Token.objects.get_or_create(user = user_object)    
                    return Response({'message':'Registration Successful'},status.HTTP_200_OK)
                return Response({'message':'Passwords does not match.. Please check the credentials..'},status.HTTP_400_BAD_REQUEST)
            


class LoginPage(APIView):
    serializer_class= LoginSerializer
    
    def post(self,request):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            user_mail  = serializer.validated_data['email']
            password  = serializer.validated_data['password']
            if Admin_User_Configuration.objects.filter(EMAIL = user_mail).exists():
                saved_password = Admin_User_Configuration.objects.filter(EMAIL=user_mail).values()[0].get('PASSWORD')  
                if check_password(password,saved_password):
                    if User.objects.filter(email=user_mail):
                        user_object = User(email = user_mail)
                        token , created = Token.objects.get_or_create(user = user_object)
                        return Response({'message':'Login Successful','token':token.key},status.HTTP_200_OK)
                return Response({'message':'Please Check the Credentials or Register to continue..'},status.HTTP_400_BAD_REQUEST)
        
class ForgotPasswordEmail(APIView):
    serializer_class = SignUpFirstPageSerializer
    
    def post(self,request):
        serializer = SignUpFirstPageSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            recipient_mail  = serializer.validated_data['email']
            if User.objects.filter(email = recipient_mail).exists() or Admin_Setup.objects.filter(EMAIL=recipient_mail).exists():
                msg = EmailMessage()
                msg['Subject'] = 'LNT MF Sales Incentive: Reset Password Verification OTP'
                msg['From'] = 'kgdineshkiruthik@outlook.com'
                msg['To'] = recipient_mail
                otp = random.randint(100001,999999)
                otp_object = OTP_Verification(email = recipient_mail,OTP = otp)
                otp_object.save()
                content = f'Hello {recipient_mail}, Your OTP for verification is {otp}. Please do not share the OTP to anyone.'
                msg.set_content(content)
                s = smtplib.SMTP('smtp-mail.outlook.com',port=587)
                context=ssl.create_default_context()
                s.starttls(context=context)
                s.ehlo()
                s.login('kgdineshkiruthik@outlook.com','Happyman@1996')
                s.send_message(msg)
                s.quit()
                return Response({'message':'OTP for Verification is sent to your email'},status.HTTP_200_OK)
        
class ResetPassword(APIView):
    serializer_class = ResetPasswordSerializer
    
    def post(self,request):
        serializer = ResetPasswordSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            otp = serializer.validated_data['OTP']
            email = serializer.validated_data['email']
            new_password1 = serializer.validated_data['password1']
            new_password2 = serializer.validated_data['password2']
            if User.objects.filter(email=email).exists() or Admin_Setup.objects.filter(EMAIL = email).exists():
                if new_password1 == new_password2:
                    if OTP_Verification.objects.filter(email=email).values()[0].get('OTP')==otp:
                        hashed = make_password(new_password1)
                        user_obj = User.objects.get(email=email)
                        user_obj.password = hashed
                        user_obj.save()
                        admin_obj = Admin_User_Configuration.objects.get(EMAIL=email)
                        admin_obj.PASSWORD = hashed
                        admin_obj.save()
                        return Response({'message':'Password Changed Successfully'},status.HTTP_200_OK)
                    return Response({'message':'Password Reset Unsuccessful..Please Check the credentials..'},
                            status.HTTP_400_BAD_REQUEST)  
                return Response({'message':'Passwords does not match.. Please check the credentials..'},status.HTTP_400_BAD_REQUEST)
            return Response({'message':'Invalid Email ID'},status.HTTP_400_BAD_REQUEST)   
        
        
class LogoutView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [TokenAuthentication]
    def post(self,request):
        request.user.auth_token.delete()
        return Response({'message':'You are Logged out Successfully'},status.HTTP_200_OK)
        