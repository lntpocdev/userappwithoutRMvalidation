from rest_framework import serializers
from . models import *

class SignUpFirstPageSerializer(serializers.Serializer):
    
        email = serializers.EmailField()
 
class CustomAuthTokenSerializer(serializers.Serializer):
        email = serializers.EmailField()
        password = serializers.CharField(max_length=255)
         
                

class SignUpRegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model=User        
        fields = ['email','password1','OTP','password2']
        
        
        
        
class LoginSerializer(serializers.Serializer):
        email = serializers.EmailField()
        password = serializers.CharField(max_length=255)
        
        

class ResetPasswordSerializer(serializers.Serializer):
    email = serializers.EmailField()
    reset_password = serializers.CharField(max_length=255)
    OTP = serializers.CharField(max_length=255)