
from django.db import models
from django.contrib.auth.models import AbstractUser


from django.db import models

from django.db import models



class User(AbstractUser):
    class Meta:
        db_table = 'USER_TABLE'
    
    email = models.EmailField(primary_key=True)
    password1 = models.CharField(max_length=255,null=True)
    OTP = models.CharField(max_length=255,null=True)
    password2 = models.CharField(max_length=255,null=True)
    RM_user = models.BooleanField(default=False)
    
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []
    
    
class OTP_Verification(models.Model):
    class Meta:
        db_table = 'VERIFICATION_TABLE'
    email = models.EmailField(primary_key=True)
    OTP = models.CharField(max_length=255,null=True)
    

class Admin_Setup(models.Model):
    class Meta:
        db_table = 'LT_ADMIN_SETUP'
    
    FROM_DATE= models.DateField()
    TO_DATE = models.DateField()
    ADMIN_NAME = models.CharField(max_length=255)
    EMAIL = models.EmailField(primary_key=True)
    MOBILE_NO = models.CharField(max_length=10)
    DESIGNATION = models.CharField(max_length=255)
    
    
class Admin_User_Configuration(models.Model):
    class Meta:
        db_table='ADMIN_USER_CONFIGURATION'
        
    RM_CODE = models.CharField(max_length=255,null=True)
    NAME = models.CharField(max_length=255,null=True)
    EMAIL = models.EmailField(primary_key=True)
    MOBILE= models.CharField(max_length=10,null=True)
    PINCODE=models.IntegerField(max_length=6,null=True)
    DESIGNATION=models.CharField(max_length=255,null=True)
    REPORTS_TO=models.CharField(max_length=255,null=True)
    PASSWORD=models.CharField(max_length=255,null=True)
    
